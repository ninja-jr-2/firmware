this file contains close to 15000 ssid's to be used with ssid broadcast option on enhanced karma.

extract and place ssid_list.txt in the root of your sd card or littlefs.